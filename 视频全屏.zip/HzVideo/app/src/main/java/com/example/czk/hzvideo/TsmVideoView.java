package com.example.czk.hzvideo;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.VideoView;

/**
 * Created by czk on 2016/1/12.
 */
public class TsmVideoView extends VideoView {
    public TsmVideoView(Context context) {
        super(context);
    }

    public TsmVideoView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public TsmVideoView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    }
}
