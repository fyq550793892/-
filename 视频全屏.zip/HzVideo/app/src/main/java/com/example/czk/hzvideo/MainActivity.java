package com.example.czk.hzvideo;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.Display;
import android.view.View;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.VideoView;

public class MainActivity extends Activity implements View.OnClickListener {
    private VideoView vv_video_paly;
    private RelativeLayout rl;
    private int orientation;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(isScreenOriatationPortrait(this)){
            setContentView(R.layout.activity_main);
        } else{
            setContentView(R.layout.activity_main2);
        }
        initViews();
        play();
    }

    /**
     * 保存 旋转 之前的 数据
     *
     * @param outState
     */
    @Override
    protected void onRestoreInstanceState(Bundle outState) {
        int sec =outState.getInt("time");
        vv_video_paly.seekTo(sec);
        super.onRestoreInstanceState(outState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        int sec = vv_video_paly.getCurrentPosition();
        outState.putInt("time", sec);
        super.onSaveInstanceState(outState);
    }


    private void initViews() {
        //
        vv_video_paly = (VideoView) findViewById(R.id.vv_main);
        rl = (RelativeLayout) findViewById(R.id.ll_main);
        rl.setOnClickListener(this);
    }

    /**
     * 视频播放
     */
    private void play() {
        //
        vv_video_paly.setVideoPath(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).getAbsolutePath() +"/3.MP4");
        Toast.makeText(MainActivity.this,Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).getAbsolutePath() +"/3.MP4", Toast.LENGTH_SHORT).show();
        MediaController mediaController = new MediaController(this);
        mediaController.setMediaPlayer(vv_video_paly);
        vv_video_paly.setMediaController(mediaController);
        vv_video_paly.start();
        // 视频缓冲完成是的监听
        vv_video_paly.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.start();// 播放
                mp.setLooping(true);
            }
        });
        // 视频或者音频到结尾时触发的方法
        vv_video_paly.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Toast.makeText(MainActivity.this, "播放完成", Toast.LENGTH_SHORT).show();
                fileList();
            }
        });
        //播放途中出现错误
        vv_video_paly.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                Toast.makeText(MainActivity.this, "播放中出现错误", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
    }

    /**
     * 横竖屏
     */
    public void setOratation() {
        Display display = getWindowManager().getDefaultDisplay();
        int width = display.getWidth();
        int height = display.getHeight();
        if (width > height) {
            orientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;  //竖屏
        } else {
            orientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;  //横屏

        }
        this.setRequestedOrientation(orientation);
    }
    /**
     * 判断横竖屏
     */
    public static boolean isScreenOriatationPortrait(Context context) {
        return context.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT;
    }


    private long lastPressedMillis;

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.ll_main:
                if (lastPressedMillis + 2000 > System.currentTimeMillis()) {
                    setOratation();
                } else {
                    if (isScreenOriatationPortrait(MainActivity.this)) {
                        Toast.makeText(MainActivity.this, "双击全屏", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "双击退出全屏", Toast.LENGTH_SHORT).show();
                    }
                    lastPressedMillis = System.currentTimeMillis();
                }
                break;
        }
    }
}