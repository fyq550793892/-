package com.example.czk.hzvideo;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Toast;
import android.widget.VideoView;

public class MainActivity3 extends Activity implements View.OnClickListener {
    private VideoView vv_video_paly;
    private RelativeLayout rl;
    private int positon;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_main2);
        initViews();
        play();
    }

    private void initViews() {
        positon = getIntent().getIntExtra("position", 0);
        //
        vv_video_paly = (VideoView) findViewById(R.id.vv_main);
        vv_video_paly.setOnClickListener(this);
        rl = (RelativeLayout) findViewById(R.id.ll_main);
        rl.setOnClickListener(this);
        rl.requestFocus();
    }

    /**
     * 视频播放
     */
    private void play() {
        //
        vv_video_paly.setVideoPath(Environment.getExternalStorageDirectory().getAbsolutePath() + "/3.MP4");
        MediaController mediaController = new MediaController(this);
        mediaController.setMediaPlayer(vv_video_paly);
        vv_video_paly.setMediaController(mediaController);
        vv_video_paly.seekTo(positon);
        vv_video_paly.start();
        vv_video_paly.requestFocus();
        // 视频或者音频到结尾时触发的方法
        vv_video_paly.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Toast.makeText(MainActivity3.this, "播放完成", Toast.LENGTH_SHORT).show();
                positon = 0;
                fileList();
            }
        });
        //播放途中出现错误
        vv_video_paly.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                Toast.makeText(MainActivity3.this, "播放中出现错误", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        if (vv_video_paly.isPlaying()) {
            positon = vv_video_paly.getCurrentPosition();
        }
    }


    private long lastPressedMillis;

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.ll_main:
                if (lastPressedMillis + 2000 > System.currentTimeMillis()) {
                    positon = vv_video_paly.getCurrentPosition();
                    Intent intent = new Intent();
                    intent.putExtra("position", positon);
                    setResult(RESULT_OK, intent);
                    finish();
                } else {
                    Toast.makeText(MainActivity3.this, "双击退出全屏", Toast.LENGTH_SHORT).show();
                }
                lastPressedMillis = System.currentTimeMillis();
                break;
        }

    }

    @Override
    public void onBackPressed() {
        positon = vv_video_paly.getCurrentPosition();
        Intent intent = new Intent();
        intent.putExtra("position", positon);
        setResult(RESULT_OK, intent);
        finish();
    }

}